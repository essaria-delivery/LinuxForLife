<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>Copyright &copy; 2018 <a target=_"blank" href="https://gogrocer.app/"> <?php echo "GoGrocer";?></a>.</strong> All rights reserved.
      </footer>